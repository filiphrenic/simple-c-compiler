

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;

/**
 * This class reads the automatons from a file, creates a lexical analyzer based
 * on those automatons and analyzes the input
 * 
 * @author fhrenic
 */
public class LA {

    public static void main(String[] args) throws FileNotFoundException {
        InputStream input = System.in;
        new LA(input, System.out).lexicalAnalysis();
    }

    private InputStream input;
    private OutputStream output;

    /**
     * Creates a new Lexical Analyzer that analyzes the input stream and prints
     * the results to the output stream
     * 
     * @param input input stream to analyze
     * @param output output stream to show the results
     */
    public LA(InputStream input, OutputStream output) {
        this.input = input;
        this.output = output;
    }

    /**
     * Performs lexical analysis of the input stream.
     */
    @SuppressWarnings("unchecked")
    public void lexicalAnalysis() {
        try (ObjectInputStream stream = Streamer.getInput()) {
            String startState = (String) stream.readObject();
            HashMap<String, List<LexRule>> states = (HashMap<String, List<LexRule>>) stream
                    .readObject();
            AutomatonHandler handler = (AutomatonHandler) stream.readObject();
            new Lex(startState, states, handler, output).analyzeInput(input);
        } catch (IOException | ClassNotFoundException ex) {
            // TODO: handle exception
        }
    }

}
